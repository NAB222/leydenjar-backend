"""
Table creation.

Run this once (locally: `python -m db.create_tables`; on Render: as a
one-off shell command, or it's called automatically at app startup in
main.py) to create the kpi_snapshots table if it doesn't exist yet.
"""
from db.database import Base, engine
from db import models  # noqa: F401  (import registers the model with Base)


def create_tables():
    Base.metadata.create_all(bind=engine)


if __name__ == "__main__":
    create_tables()
    print("Tables created (or already existed).")
