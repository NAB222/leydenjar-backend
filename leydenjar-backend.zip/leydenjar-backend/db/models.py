"""
Database models.

The tracker spreadsheets are periodic snapshots (you export/update them by
hand), so rather than modeling every individual KPI column - which would
need a migration every time a sheet's layout changes - this stores each
overview as a timestamped JSON snapshot. That's enough to answer "how has
this changed since last month" without coupling the schema to the current
shape of the Excel trackers.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Integer, JSON, String

from db.database import Base, SessionLocal


class KPISnapshot(Base):
    """One point-in-time capture of a KPI overview (GA, LinkedIn, or combined)."""

    __tablename__ = "kpi_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    source = Column(String(32), nullable=False, index=True)  # "ga" | "linkedin" | "combined"
    captured_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    payload = Column(JSON, nullable=False)

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "source": self.source,
            "captured_at": self.captured_at.isoformat() if self.captured_at else None,
            "payload": self.payload,
        }


def save_snapshot(source: str, payload: dict) -> None:
    """Persist one KPI overview as a snapshot. Best-effort: a database
    problem here should never break the API response that triggered it."""
    db = SessionLocal()
    try:
        db.add(KPISnapshot(source=source, payload=payload))
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()


def list_snapshots(source: str, limit: int = 50) -> list[dict]:
    db = SessionLocal()
    try:
        rows = (
            db.query(KPISnapshot)
            .filter(KPISnapshot.source == source)
            .order_by(KPISnapshot.captured_at.desc())
            .limit(limit)
            .all()
        )
        return [r.as_dict() for r in rows]
    finally:
        db.close()
