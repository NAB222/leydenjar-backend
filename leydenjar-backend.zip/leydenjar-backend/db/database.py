"""
Database connection.

Uses DATABASE_URL when it's set (Render injects this automatically once a
PostgreSQL instance is attached to the service). Falls back to a local
SQLite file so the app - and `create_tables.py` - still work with no
database configured at all, e.g. when running locally.
"""
import os
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    sqlite_path = Path(__file__).resolve().parent.parent / "leydenjar.db"
    DATABASE_URL = f"sqlite:///{sqlite_path}"

# Render (and most managed Postgres providers) hand out a DATABASE_URL that
# starts with "postgres://", which older SQLAlchemy no longer accepts.
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency: yields a session, closes it after the request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
