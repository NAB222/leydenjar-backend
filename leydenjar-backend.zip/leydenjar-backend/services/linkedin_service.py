"""
LinkedIn post tracker service.

Parses data/linkedin_posttracker.xlsx (the manually-maintained post log
Noelle updates after every post) and exposes get_linkedin_overview(), a
single JSON-serializable dictionary of the KPIs the API surfaces.
"""
from datetime import date, datetime, time
from functools import lru_cache
from pathlib import Path

import openpyxl

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "linkedin_posttracker.xlsx"


def _load_workbook():
    return openpyxl.load_workbook(DATA_PATH, data_only=True)


def _json_safe(value):
    """Guard against a stray Excel time-of-day cell breaking JSON encoding
    (see ga_service._json_safe for the same issue on that workbook).
    datetime/date values are left alone since callers convert those
    explicitly via _iso()."""
    if isinstance(value, time):
        return value.strftime("%H:%M:%S")
    return value


def _clean(d: dict) -> dict:
    return {k: _json_safe(v) for k, v in d.items() if k is not None}


def _iso(value):
    if isinstance(value, (datetime, date)):
        return value.strftime("%Y-%m-%d")
    return value


def _totals(ws) -> dict:
    return {
        "total_posts": ws["A4"].value,
        "total_impressions": ws["C4"].value,
        "total_engagement": ws["E4"].value,
        "avg_engagement_rate": ws["G4"].value,
    }


def _by_post_type(ws) -> list[dict]:
    header = [c.value for c in ws[7]]
    rows = []
    for row in ws.iter_rows(min_row=8, max_row=14, values_only=True):
        if row[0] is None:
            continue
        rows.append(_clean(dict(zip(header, row))))
    return rows


def _by_day_of_week(ws) -> list[dict]:
    header = [c.value for c in ws[19]]
    rows = []
    for row in ws.iter_rows(min_row=20, max_row=26, values_only=True):
        if row[0] is None:
            continue
        rows.append(_clean(dict(zip(header, row))))
    return rows


def _monthly_rollup(ws) -> list[dict]:
    header = [c.value for c in ws[4]]
    rows = []
    for row in ws.iter_rows(min_row=5, max_row=ws.max_row, values_only=True):
        if row[0] is None or row[0] == "YEAR TOTAL":
            continue
        rows.append(_clean(dict(zip(header, row))))
    return rows


def _post_log(ws) -> list[dict]:
    header = [c.value for c in ws[4]]
    posts = []
    for row in ws.iter_rows(min_row=5, max_row=ws.max_row, values_only=True):
        if row[0] is None or row[1] is None:
            continue
        entry = _clean(dict(zip(header, row)))
        entry["Date Posted"] = _iso(entry.get("Date Posted"))
        posts.append(entry)
    return posts


def _recent_posts(posts: list[dict], limit: int = 10) -> list[dict]:
    with_dates = [p for p in posts if p.get("Date Posted")]
    return sorted(with_dates, key=lambda p: p["Date Posted"], reverse=True)[:limit]


def _follower_growth(ws) -> dict:
    header = [c.value for c in ws[3]]
    daily = []
    gain_since = None
    for row in ws.iter_rows(min_row=4, max_row=ws.max_row, values_only=True):
        if row[0] is None:
            continue
        if isinstance(row[0], str) and "gain" in row[0].lower():
            gain_since = row[1]
            continue
        if row[3] is None:
            continue
        entry = _clean(dict(zip(header, row)))
        entry["Date"] = _iso(entry.get("Date"))
        daily.append(entry)
    return {"daily": daily, "gain_since_period_start": gain_since}


@lru_cache(maxsize=1)
def _overview() -> dict:
    wb = _load_workbook()
    dashboard = wb["Dashboard"]
    post_log_ws = wb["Post Log"]
    monthly_ws = wb["Monthly Rollup"]
    followers_ws = wb["Follower Growth"]

    post_log = _post_log(post_log_ws)

    return {
        "period": "June 2025 - June 2026",
        "totals": _totals(dashboard),
        "by_post_type": _by_post_type(dashboard),
        "by_day_of_week": _by_day_of_week(dashboard),
        "monthly_rollup": _monthly_rollup(monthly_ws),
        "recent_posts": _recent_posts(post_log),
        "post_count_logged": len(post_log),
        "follower_growth": _follower_growth(followers_ws),
    }


def get_linkedin_overview() -> dict:
    """Full LinkedIn KPI overview, cached after first read. Restart the app
    to pick up edits made to the source workbook."""
    return _overview()


@lru_cache(maxsize=1)
def get_post_log() -> list[dict]:
    """The full parsed Post Log (all rows, not just the 10 most recent) -
    used by the utils/ modules for per-post analysis."""
    wb = _load_workbook()
    return _post_log(wb["Post Log"])
