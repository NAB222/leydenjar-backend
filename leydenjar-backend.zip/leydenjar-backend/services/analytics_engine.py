"""
Cross-channel analytics engine.

Combines the GA and LinkedIn tracker services into a single "how's our
marketing doing" snapshot. The two trackers don't share a clean join key
(different reporting granularity and periods), so rather than forcing a
row-for-row merge, this surfaces the headline number from each source
side by side plus a few derived cross-channel ratios that stand on their
own.
"""
from services.ga_service import get_ga_overview
from services.linkedin_service import get_linkedin_overview


def _find_channel(channels: list[dict], name: str) -> dict:
    for row in channels:
        if row.get("Channel") == name:
            return row
    return {}


def get_combined_overview() -> dict:
    ga = get_ga_overview()
    li = get_linkedin_overview()

    ga_key = ga.get("key_metrics", {})
    li_totals = li.get("totals", {})
    organic_social = _find_channel(ga.get("acquisition_channels", []), "Organic Social")

    website_sessions = ga_key.get("Sessions")
    li_impressions = li_totals.get("total_impressions")

    sessions_per_1k_impressions = None
    if website_sessions and li_impressions:
        sessions_per_1k_impressions = round(website_sessions / li_impressions * 1000, 2)

    top_ga_channel = max(
        ga.get("acquisition_channels", []),
        key=lambda r: r.get("Sessions (All)") or 0,
        default=None,
    )
    top_li_post_type = max(
        li.get("by_post_type", []),
        key=lambda r: r.get("Avg Eng. Rate") or 0,
        default=None,
    )

    return {
        "ga_period": ga.get("period"),
        "linkedin_period": li.get("period"),
        "headline": {
            "website_total_users": ga_key.get("Total Users"),
            "website_sessions": website_sessions,
            "website_engagement_rate": ga_key.get("Engagement Rate"),
            "linkedin_total_posts": li_totals.get("total_posts"),
            "linkedin_total_impressions": li_impressions,
            "linkedin_total_engagement": li_totals.get("total_engagement"),
            "linkedin_avg_engagement_rate": li_totals.get("avg_engagement_rate"),
            "linkedin_follower_gain": li.get("follower_growth", {}).get("gain_since_period_start"),
        },
        "cross_channel": {
            "website_sessions_from_organic_social": organic_social.get("Sessions (All)"),
            "website_users_from_organic_social": organic_social.get("All Users"),
            "website_sessions_per_1000_linkedin_impressions": sessions_per_1k_impressions,
        },
        "top_ga_channel_by_sessions": top_ga_channel,
        "top_linkedin_post_type_by_engagement_rate": top_li_post_type,
    }
