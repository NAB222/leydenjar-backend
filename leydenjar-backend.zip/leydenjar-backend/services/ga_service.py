"""
Google Analytics tracker service.

Parses data/google_analytics_tracker_2.xlsx (the GA export workbook Noelle
maintains) and exposes get_ga_overview(), a single JSON-serializable
dictionary of the KPIs the API surfaces.

The workbook is a manually-curated tracker, not a live GA export, so this
reads its fixed sheet layout directly with openpyxl rather than assuming a
tidy table. If the sheet layout changes, the row/column anchors below will
need updating.
"""
from datetime import date, datetime, time
from functools import lru_cache
from pathlib import Path

import openpyxl

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "google_analytics_tracker_2.xlsx"


def _load_workbook():
    return openpyxl.load_workbook(DATA_PATH, data_only=True)


def _json_safe(value):
    """A handful of cells in this hand-maintained sheet get auto-formatted
    by Excel as time-of-day values (e.g. typing '1:15' becomes a time
    object) instead of the text durations used everywhere else, and
    datetime.time isn't JSON-serializable on its own. Normalize just that
    case to a plain string; datetime/date values are left alone since
    callers (e.g. the Week column) convert those explicitly themselves."""
    if isinstance(value, time):
        return value.strftime("%H:%M:%S")
    return value


def _clean(d: dict) -> dict:
    """Drop None keys picked up from blank/merged header cells, and make
    every value JSON-safe."""
    return {k: _json_safe(v) for k, v in d.items() if k is not None}


def _parse_week_label(value):
    """The 'Weekly data updates' sheet mixes real datetimes with text dates
    like '6/18/26' entered by hand — normalize both to ISO date strings."""
    if isinstance(value, (datetime, date)):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, str) and value.strip():
        for fmt in ("%m/%d/%y", "%m/%d/%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(value.strip(), fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return value.strip()
    return None


def _key_metrics(ws) -> dict:
    header = [c.value for c in ws[5]]
    values = [c.value for c in ws[6]]
    return _clean(dict(zip(header, values)))


def _country_comparison(ws) -> list[dict]:
    header = [c.value for c in ws[9]]
    rows = []
    for row in ws.iter_rows(min_row=10, max_row=13, values_only=True):
        if row[0] is None:
            continue
        rows.append(_clean(dict(zip(header, row))))
    return rows


def _acquisition_channels(ws) -> list[dict]:
    header = [c.value for c in ws[18]]
    rows = []
    for row in ws.iter_rows(min_row=19, max_row=28, values_only=True):
        if row[0] is None:
            continue
        rows.append(_clean(dict(zip(header, row))))
    return rows


def _top_content(ws) -> dict:
    pages, sources, events = [], [], []
    for row in ws.iter_rows(min_row=32, max_row=38, values_only=True):
        if row[0]:
            pages.append({"name": row[0], "value": row[1]})
        if row[2]:
            sources.append({"name": row[2], "value": row[3]})
        if row[4]:
            events.append({"name": row[4], "value": row[5]})
    return {"top_pages": pages, "top_sources": sources, "top_events": events}


def _traffic_by_channel(ws) -> list[dict]:
    header = [c.value for c in ws[2]]
    rows = []
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row, values_only=True):
        if row[0] is None:
            continue
        rows.append(_clean(dict(zip(header, row))))
    return rows


def _weekly_trend(ws) -> list[dict]:
    header = [h.strip() if isinstance(h, str) else h for h in (c.value for c in ws[2])]
    rows = []
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row, values_only=True):
        if row[0] is None or row[1] is None:
            continue
        entry = _clean(dict(zip(header, row)))
        entry["Week"] = _parse_week_label(entry.get("Week"))
        # The source sheet has at least one stray trailing space on a
        # country value ("China "); normalize so it doesn't fork into a
        # separate series in the UI.
        if isinstance(entry.get("Country"), str):
            entry["Country"] = entry["Country"].strip()
        rows.append(entry)
    rows.sort(key=lambda r: (r.get("Week") or "", r.get("Country") or ""))
    return rows


@lru_cache(maxsize=1)
def _overview() -> dict:
    wb = _load_workbook()
    annual = wb["Annual Snapshot"]
    traffic = wb["Traffic Acquisition"]
    weekly = wb["Weekly data updates"]

    return {
        "period": "Jun 30, 2025 - Jun 30, 2026",
        "key_metrics": _key_metrics(annual),
        "by_country": _country_comparison(annual),
        "acquisition_channels": _acquisition_channels(annual),
        "traffic_by_channel": _traffic_by_channel(traffic),
        **_top_content(annual),
        "weekly_trend": _weekly_trend(weekly),
    }


def get_ga_overview() -> dict:
    """Full GA KPI overview, cached after first read. Restart the app to
    pick up edits made to the source workbook."""
    return _overview()
