"""
Posting effectiveness.

Scores each logged LinkedIn post against two baselines: how it did
relative to other posts of the same type, and relative to other posts on
the same day of week. A post can only be judged against its peers, so
"effective" here means "outperformed comparable posts," not an absolute
target.
"""
from statistics import mean

from services.linkedin_service import get_post_log

_RATE_FIELD = "Engagement Rate %"
_TYPE_FIELD = "Post Type"
_DAY_FIELD = "Day of Week"


def _group_average_rates(posts: list[dict], field: str) -> dict:
    buckets: dict[str, list[float]] = {}
    for p in posts:
        key = p.get(field)
        rate = p.get(_RATE_FIELD)
        if key is None or rate is None:
            continue
        buckets.setdefault(key, []).append(rate)
    return {k: mean(v) for k, v in buckets.items() if v}


def _label(delta: float) -> str:
    if delta >= 0.25:
        return "high performer"
    if delta <= -0.25:
        return "underperformer"
    return "average"


def get_posting_effectiveness() -> dict:
    posts = get_post_log()
    by_type_avg = _group_average_rates(posts, _TYPE_FIELD)
    by_day_avg = _group_average_rates(posts, _DAY_FIELD)

    scored = []
    for p in posts:
        rate = p.get(_RATE_FIELD)
        if rate is None:
            continue
        type_avg = by_type_avg.get(p.get(_TYPE_FIELD))
        day_avg = by_day_avg.get(p.get(_DAY_FIELD))
        vs_type = (rate / type_avg - 1) if type_avg else None
        vs_day = (rate / day_avg - 1) if day_avg else None
        deltas = [d for d in (vs_type, vs_day) if d is not None]
        overall_delta = mean(deltas) if deltas else 0.0

        scored.append({
            "post_number": p.get("Post #"),
            "date_posted": p.get("Date Posted"),
            "topic": p.get("Post Title/Topic"),
            "post_type": p.get(_TYPE_FIELD),
            "day_of_week": p.get(_DAY_FIELD),
            "engagement_rate": rate,
            "vs_type_average_pct": round(vs_type * 100, 1) if vs_type is not None else None,
            "vs_day_average_pct": round(vs_day * 100, 1) if vs_day is not None else None,
            "rating": _label(overall_delta),
        })

    scored.sort(key=lambda r: r["engagement_rate"], reverse=True)

    return {
        "baseline_by_post_type": {k: round(v, 4) for k, v in by_type_avg.items()},
        "baseline_by_day_of_week": {k: round(v, 4) for k, v in by_day_avg.items()},
        "posts": scored,
        "top_performers": scored[:5],
        "underperformers": [p for p in scored if p["rating"] == "underperformer"][-5:],
    }
