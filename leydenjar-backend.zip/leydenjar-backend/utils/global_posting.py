"""
Global posting recommendations.

Recommends which day(s) and post type(s) tend to perform best, from the
day-of-week and post-type rollups already computed in the LinkedIn
tracker. The post log has no time-of-day data (every "Time Posted" cell is
blank), so this can only speak to day and format - not hour.
"""
from services.linkedin_service import get_linkedin_overview

_MIN_SAMPLE = 3  # below this many posts, flag low confidence rather than recommend


def _rank(rows: list[dict], key_field: str, rate_field: str = "Avg Eng. Rate", count_field: str = "# Posts") -> list[dict]:
    ranked = [r for r in rows if r.get(key_field) != "TOTAL" and r.get(rate_field) is not None]
    ranked.sort(key=lambda r: r[rate_field], reverse=True)
    out = []
    for r in ranked:
        count = r.get(count_field) or 0
        out.append({
            "name": r.get(key_field),
            "post_count": count,
            "avg_engagement_rate": round(r[rate_field], 4),
            "avg_impressions": r.get("Avg Impressions"),
            "confidence": "low (small sample)" if count < _MIN_SAMPLE else "ok",
        })
    return out


def get_global_posting_recommendations() -> dict:
    li = get_linkedin_overview()
    days_ranked = _rank(li.get("by_day_of_week", []), "Day")
    types_ranked = _rank(li.get("by_post_type", []), "Post Type")

    confident_days = [d for d in days_ranked if d["confidence"] == "ok"]
    confident_types = [t for t in types_ranked if t["confidence"] == "ok"]

    best_day = confident_days[0] if confident_days else (days_ranked[0] if days_ranked else None)
    best_type = confident_types[0] if confident_types else (types_ranked[0] if types_ranked else None)

    recommendation = None
    if best_day and best_type:
        recommendation = (
            f"Post {best_type['name']} content on {best_day['name']}s - "
            f"they lead their category at {best_day['avg_engagement_rate'] * 100:.2f}% and "
            f"{best_type['avg_engagement_rate'] * 100:.2f}% avg. engagement rate respectively."
        )

    return {
        "days_ranked_by_engagement_rate": days_ranked,
        "post_types_ranked_by_engagement_rate": types_ranked,
        "best_day": best_day,
        "best_post_type": best_type,
        "recommendation": recommendation,
        "note": "No time-of-day data is logged in the post tracker, so this covers day and format only.",
    }
