"""
Content insights.

Looks at what the posts were actually about - hashtags and monthly
performance - rather than just format (utils/global_posting.py) or
per-post scoring (utils/posting_effectiveness.py).
"""
from statistics import mean

from services.linkedin_service import get_linkedin_overview, get_post_log

_MIN_HASHTAG_SAMPLE = 2


def _hashtag_performance() -> list[dict]:
    posts = get_post_log()
    # Group case-insensitively (the tracker has both "#SiliconAnode" and
    # "#Siliconanode"), and strip the literal "hashtag" LinkedIn sometimes
    # glues onto the front when text is copy-pasted from its UI
    # ("hashtag#SiliconAnode" -> "#SiliconAnode").
    buckets: dict[str, dict] = {}  # lowercased tag -> {"display": str, "posts": [...]}
    for p in posts:
        tags = p.get("Hashtags")
        rate = p.get("Engagement Rate %")
        if not tags or rate is None:
            continue
        for raw in tags.replace("hashtag#", " #").split():
            tag = raw.strip()
            if not tag.startswith("#") or len(tag) < 2:
                continue
            key = tag.lower()
            bucket = buckets.setdefault(key, {"display": tag, "posts": []})
            bucket["posts"].append(p)

    out = []
    for key, bucket in buckets.items():
        tag = bucket["display"]
        tagged_posts = bucket["posts"]
        rates = [p["Engagement Rate %"] for p in tagged_posts if p.get("Engagement Rate %") is not None]
        impressions = [p["Impressions"] for p in tagged_posts if p.get("Impressions") is not None]
        if not rates:
            continue
        out.append({
            "hashtag": tag,
            "post_count": len(tagged_posts),
            "avg_engagement_rate": round(mean(rates), 4),
            "avg_impressions": round(mean(impressions), 0) if impressions else None,
            "confidence": "low (small sample)" if len(tagged_posts) < _MIN_HASHTAG_SAMPLE else "ok",
        })
    out.sort(key=lambda r: r["avg_engagement_rate"], reverse=True)
    return out


def _monthly_extremes(monthly_rollup: list[dict]) -> dict:
    rows = [r for r in monthly_rollup if r.get("# Posts")]
    if not rows:
        return {"best_month": None, "worst_month": None}
    by_rate = sorted(rows, key=lambda r: r.get("Avg Eng. Rate") or 0, reverse=True)
    return {"best_month": by_rate[0], "worst_month": by_rate[-1]}


def get_content_insights() -> dict:
    li = get_linkedin_overview()
    hashtags = _hashtag_performance()
    extremes = _monthly_extremes(li.get("monthly_rollup", []))

    confident_hashtags = [h for h in hashtags if h["confidence"] == "ok"]
    top_hashtags = confident_hashtags[:5]
    headlines = []

    by_type = sorted(
        (t for t in li.get("by_post_type", []) if t.get("Post Type") != "TOTAL"),
        key=lambda r: r.get("Avg Eng. Rate") or 0,
        reverse=True,
    )
    if by_type:
        top = by_type[0]
        headlines.append(
            f"{top['Post Type']} posts have the highest average engagement rate "
            f"({top['Avg Eng. Rate'] * 100:.2f}%) across {top['# Posts']} posts."
        )
    if top_hashtags:
        h = top_hashtags[0]
        headlines.append(
            f"{h['hashtag']} is the top-performing hashtag logged, averaging "
            f"{h['avg_engagement_rate'] * 100:.2f}% engagement across {h['post_count']} posts."
        )
    if extremes["best_month"]:
        bm = extremes["best_month"]
        headlines.append(
            f"{bm['Month']} had the highest average engagement rate this year "
            f"({(bm.get('Avg Eng. Rate') or 0) * 100:.2f}%)."
        )

    return {
        "hashtag_performance": hashtags,
        "top_hashtags": top_hashtags,
        "monthly_extremes": extremes,
        "headline_insights": headlines,
        "note": "Based on the posts and hashtags currently logged in the tracker; small samples are flagged as low confidence.",
    }
