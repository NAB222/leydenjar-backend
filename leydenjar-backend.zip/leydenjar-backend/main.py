from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from services.ga_service import get_ga_overview
from services.linkedin_service import get_linkedin_overview
from services.analytics_engine import get_combined_overview
from utils.posting_effectiveness import get_posting_effectiveness
from utils.global_posting import get_global_posting_recommendations
from utils.content_insights import get_content_insights
from db.create_tables import create_tables
from db.models import save_snapshot, list_snapshots

app = FastAPI(title="LeydenJar Analytics Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # later restrict to your Vercel domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    # Safe to call every boot: create_all() is a no-op for tables that
    # already exist. If there's no DATABASE_URL this creates the local
    # SQLite fallback file instead.
    create_tables()


@app.get("/api/ga/overview")
def ga_overview():
    kpis = get_ga_overview()
    save_snapshot("ga", kpis)
    return {"kpis": kpis}


@app.get("/api/linkedin/overview")
def linkedin_overview():
    kpis = get_linkedin_overview()
    save_snapshot("linkedin", kpis)
    return {"kpis": kpis}


@app.get("/api/combined/overview")
def combined_overview():
    kpis = get_combined_overview()
    save_snapshot("combined", kpis)
    return {"kpis": kpis}


@app.get("/api/linkedin/posting-effectiveness")
def linkedin_posting_effectiveness():
    return {"kpis": get_posting_effectiveness()}


@app.get("/api/linkedin/global-posting-recommendations")
def linkedin_global_posting_recommendations():
    return {"kpis": get_global_posting_recommendations()}


@app.get("/api/content-insights")
def content_insights():
    return {"kpis": get_content_insights()}


@app.get("/api/snapshots/{source}")
def snapshots(source: str, limit: int = 50):
    """History of previously-captured overviews for a source
    ("ga" | "linkedin" | "combined"), most recent first."""
    return {"snapshots": list_snapshots(source, limit=limit)}


# Dashboard UI: a static HTML/JS page that calls the endpoints above.
# Mounted last so it doesn't shadow the /api routes, and served at "/" for
# convenience.
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def dashboard():
    return FileResponse("static/index.html")
