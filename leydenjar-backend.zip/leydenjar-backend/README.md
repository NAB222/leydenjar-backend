# LeydenJar Backend

FastAPI backend powering the LeydenJar Analytics Cockpit. Reads real data
from the GA and LinkedIn tracker spreadsheets in `data/` (not mock data,
and not a live GA4/LinkedIn API integration - see `.env.example` if you
want to wire one of those in later).

## Endpoints

### `/api/ga/overview`
Google Analytics KPIs: key metrics, country comparison, acquisition
channels, top pages/sources/events, weekly trend.

### `/api/linkedin/overview`
LinkedIn KPIs: totals, post-type and day-of-week breakdowns, monthly
rollup, recent posts, follower growth.

### `/api/combined/overview`
Unified KPIs combining GA + LinkedIn (sessions per 1,000 impressions,
sessions from Organic Social, etc.).

### `/api/linkedin/posting-effectiveness`
Each logged post scored against its post-type and day-of-week baseline.

### `/api/linkedin/global-posting-recommendations`
Best day and post type to publish, ranked from the tracker's day-of-week
and post-type rollups.

### `/api/content-insights`
Hashtag performance and monthly extremes, plus a few plain-language
headline findings.

### `/api/snapshots/{source}`
History of previously-captured overviews (`source` is `ga`, `linkedin`,
or `combined`) - each hit to the three `/overview` endpoints above is
saved as a timestamped snapshot, so this becomes useful once the app's
been running for a while.

### `/`
A small built-in dashboard (`static/index.html`) that calls the endpoints
above and renders KPI tiles, charts, and the posting insights.

## Data

Update `data/google_analytics_tracker_2.xlsx` and
`data/linkedin_posttracker.xlsx` and restart the app to pick up changes -
they're read once at first request and cached.

## Database

Optional. Set `DATABASE_URL` (Render provides this automatically once you
attach a PostgreSQL instance) to persist KPI snapshots there; otherwise
the app falls back to a local SQLite file (`leydenjar.db`) so it still
runs with no database configured.

## Deployment

Deploy on Render using the included `Dockerfile`. Attach a PostgreSQL
instance if you want snapshot history to persist across deploys (SQLite
lives on the container's ephemeral disk and won't survive a redeploy).

## Local development

```
pip install -r requirements.txt
uvicorn main:app --reload
```

Then open `http://localhost:8000`.
